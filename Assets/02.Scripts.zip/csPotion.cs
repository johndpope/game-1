﻿using UnityEngine;
using System.Collections;

public class csPotion : MonoBehaviour
{

	void Start ()
    {
	
	}
	
	void Update ()
    {
	
	}
}
