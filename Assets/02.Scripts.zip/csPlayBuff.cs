﻿using UnityEngine;
using System.Collections;

public class csPlayBuff : MonoBehaviour
{
    public GameObject atkUp;
    public GameObject atkDown;
    public GameObject defUp;
    public GameObject defDown;
    public GameObject spdUp;
    public GameObject spdDown;

    int playAtk;
    int playDef;
    float playSpd;

    // Use this for initialization
    void Start ()
    {
	
	}
	
	// Update is called once per frame
	void Update ()
    {
	
	}
}
